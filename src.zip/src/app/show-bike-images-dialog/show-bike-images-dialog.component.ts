import { Component } from '@angular/core';

@Component({
  selector: 'app-show-bike-images-dialog',
  templateUrl: './show-bike-images-dialog.component.html',
  styleUrls: ['./show-bike-images-dialog.component.css']
})
export class ShowBikeImagesDialogComponent {

}
