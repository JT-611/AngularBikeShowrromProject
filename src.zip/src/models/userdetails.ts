export class userdetails
{
    public email?:string
    public password?:string
}
