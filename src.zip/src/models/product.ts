export class product
{
  public id : number = 0;
  public bkmd : String = '';
  public bkengine :String = '';
  public bkclr : String = '';
  public avlqty : String = '';
  public price :  String = '';
  public desc : String = '';
}
